interface DisqusConfig {
	enabled: boolean
	shortname: string
}

export const disqusConfig: DisqusConfig = {
	enabled: false,
	shortname: ''
}
