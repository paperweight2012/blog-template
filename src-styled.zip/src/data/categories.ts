// List of categories for blog posts
export const CATEGORIES = ['Videos', 'Notes', 'Podcasts', 'Posts'] as const
